package com.example.androidtraining2.data.local.entity.relations

import androidx.room.Entity
import com.example.androidtraining2.utils.Constants.QUES_COL_PRIMARY_KEY
import com.example.androidtraining2.utils.Constants.TOPIC_PRIMARY_KEY

@Entity(primaryKeys = [QUES_COL_PRIMARY_KEY, TOPIC_PRIMARY_KEY])
data class QuesColsAndTopics(
    val quesColName: String,
    val topicName: String
)
