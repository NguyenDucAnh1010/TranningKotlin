package com.example.androidtraining2.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.androidtraining2.utils.Constants.QUESTION_PRIMARY_KEY

@Entity
data class Question(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = QUESTION_PRIMARY_KEY)
    val id: Int,
    val topicName: String,
    val quesName: String,
    val image: String?,
    val type: String?,
    val correctAns: String,
    val caseA: String,
    val caseB: String,
    val caseC: String,
    val caseD: String,
)
