package com.example.androidtraining2.data.local.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Query
import com.example.androidtraining2.data.local.entity.Question
import com.example.androidtraining2.data.local.entity.relations.TopicWithQuestions

@Dao
interface QuestionDao : BaseDao<Question> {

    @Query("SELECT * FROM question")
    fun getQuestions(): LiveData<List<Question>>

    @Query("SELECT * FROM topic WHERE topicName=:topicName")
    fun getQuestionsOfTopic(topicName: String): LiveData<TopicWithQuestions>

    @Query("SELECT * FROM question WHERE topicName=:topicName AND type=:type ORDER BY RANDOM()")
    fun getQuestions(topicName: String, type: String): LiveData<List<Question>>
}