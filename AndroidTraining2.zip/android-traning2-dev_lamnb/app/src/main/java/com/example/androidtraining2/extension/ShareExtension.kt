package com.example.androidtraining2.extension

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Environment
import android.view.View
import androidx.core.content.FileProvider
import com.example.androidtraining2.R
import com.example.androidtraining2.utils.Constants.FILE_SCREENSHOTS
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream


fun screenshot(view: View): Bitmap? {
    val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    view.draw(canvas)
    val bgDrawable = view.background
    if (bgDrawable != null)
        bgDrawable.draw(canvas)
    else
        canvas.drawColor(Color.WHITE)
    view.draw(canvas)
    return bitmap
}

fun saveBitmap(activity: Activity, bm: Bitmap, fileSave: String, fileName: String): Uri? {
    val fos: OutputStream?
    val imagesDir = activity.getExternalFilesDir(
        Environment.DIRECTORY_PICTURES
    ).toString() + File.separator + fileSave
    val file = File(imagesDir)
    if (!file.exists()) {
        file.mkdir()
    }
    val shareFile = File(imagesDir, "${fileName.formatFileName()}.png")
    fos = FileOutputStream(shareFile)
    val uri = FileProvider.getUriForFile(
        activity,
        activity.applicationContext.packageName + ".provider",
        File(shareFile.absolutePath)
    )
    bm.compress(Bitmap.CompressFormat.PNG, 100, fos)
    fos.flush()
    fos.close()
    return uri
}

fun shareScreenshot(activity: Activity, view: View, fileName: String, body: String) {
    try {
        val imagesDir = activity.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
            .toString() + File.separator +
                FILE_SCREENSHOTS +
                File.separator + fileName.formatFileName() + ".png"
        val uri = if (!File(imagesDir).exists()) {
            val bm = screenshot(view) ?: return
            saveBitmap(activity, bm, FILE_SCREENSHOTS, fileName.formatFileName()) ?: return
        } else {
            FileProvider.getUriForFile(
                activity,
                activity.applicationContext.packageName + ".provider",
                File(File(imagesDir).absolutePath)
            )
        }

        activity.share(
            body,
            "image/*",
            uri
        )
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

fun shareApplication(activity: Activity, fileName: String, link: String) {
    try {
        val imagesDir = activity.getExternalFilesDir(
            Environment.DIRECTORY_PICTURES
        ).toString() + File.separator + fileName.formatFileName() + ".png"
        val uri = if (!File(imagesDir).exists()) {
            val bm = BitmapFactory.decodeResource(activity.resources, R.drawable.logo_app)
            saveBitmap(activity, bm, "", fileName.formatFileName()) ?: return
        } else {
            FileProvider.getUriForFile(
                activity,
                activity.applicationContext.packageName + ".provider",
                File(File(imagesDir).absolutePath)
            )
        }
        activity.share(
            activity.getString(R.string.intent_application_share, link),
            "image/*",
            uri
        )
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

fun shareScore(activity: Activity, view: View, fileName: String, body: String) {
    val imagesDir = activity.getExternalFilesDir(
        Environment.DIRECTORY_PICTURES
    ).toString() + File.separator + fileName.formatFileName() + ".png"
    if (File(imagesDir).exists()) {
        File(imagesDir).delete()
    }
    val bm = screenshot(view) ?: return
    val uri = saveBitmap(activity, bm, "", fileName.formatFileName()) ?: return
    activity.share(
        body,
        "image/*",
        uri
    )
}

@SuppressLint("QueryPermissionsNeeded")
fun Activity.share(body: String, typeShare: String, uri: Uri?) {
    val shareIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(
            Intent.EXTRA_TEXT,
            body
        )
        putExtra(Intent.EXTRA_STREAM, uri)
        type = typeShare
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    Intent.createChooser(
        shareIntent,
        getString(R.string.intent_title_choose_to_share)
    ).also {
        val resInfoList =
            this.packageManager.queryIntentActivities(it, PackageManager.MATCH_DEFAULT_ONLY)

        for (resolveInfo in resInfoList) {
            val packageName = resolveInfo.activityInfo.packageName
            grantUriPermission(
                packageName,
                uri,
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        startActivity(it)
    }

}

fun String.formatFileName(): String = this.trim().replace("\\s".toRegex(), "")