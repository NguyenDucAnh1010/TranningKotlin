package com.example.androidtraining2.ui.binding

import android.view.View
import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.example.androidtraining2.R

@BindingAdapter("loadImageUrl")
fun ImageView.loadImageUrl(url: String?) {
    url?.let {
        val reqOpt = RequestOptions
                .fitCenterTransform()
            .transform(RoundedCorners(5))
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .override(this.width,this.height)
        Glide.with(context)
            .load(url)
            //.thumbnail(0.25f)
            .apply(reqOpt)
            .error(R.drawable.load_image_error).into(this)
    } ?: run {
        visibility = View.GONE
    }
}
