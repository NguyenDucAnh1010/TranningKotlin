package com.example.androidtraining2.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.androidtraining2.data.local.dao.*
import com.example.androidtraining2.data.local.entity.*
import com.example.androidtraining2.data.local.entity.relations.QuesColsAndTopics

@Database(
    entities = [
        Word::class,
        Favorite::class,
        QuestionCollection::class,
        Topic::class,
        Question::class,
        QuesColsAndTopics::class,
        Score::class
    ],
    version = 7,
    exportSchema = false
)
abstract class DictionaryDatabase : RoomDatabase() {

    abstract fun dictionaryDao(): DictionaryDao

    abstract fun quesCollectionDao(): QuesCollectionDao

    abstract fun topicDao(): TopicDao

    abstract fun questionDao(): QuestionDao

    abstract fun quesColsAndTopicsDao(): QuesColsAndTopicsDao

    abstract fun favoriteDao(): FavoriteDao

    abstract fun scoreDao(): ScoreDao
}