package com.example.androidtraining2.ui.viewmodels

import android.app.Application
import android.os.Parcelable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.androidtraining2.data.local.entity.Favorite
import com.example.androidtraining2.data.local.entity.Word
import com.example.androidtraining2.extension.convertWordToFav
import com.example.androidtraining2.presentation.repository.DictionaryRepositoryImpl
import com.example.androidtraining2.utils.Constants.DISPLAY_LIST
import com.example.androidtraining2.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DictionaryViewModel @Inject constructor(
    app: Application,
    private val repository: DictionaryRepositoryImpl
) : AndroidViewModel(app) {

    var state: Parcelable? = null
    var index = DISPLAY_LIST
    var length = DISPLAY_LIST
    var filterIndex = 0

    val words = MutableLiveData<Resource<List<Word>>>()
    val loadMoreWords = MutableLiveData<Resource<List<Word>>>()
    val filters by lazy { MutableLiveData<Resource<List<Word>>>() }
    val favoriteWords by lazy { MutableLiveData<Resource<List<Favorite>>>() }

    fun getLoadMoreWords(index: Int) = viewModelScope.launch {
        try {
            loadMoreWords.postValue(Resource.Loading())
            delay(200)
            loadMoreWords.postValue(Resource.Success(fetchFavoriteWords(repository.getAllWord(index))))
        } catch (e: Exception) {
            loadMoreWords.postValue(Resource.Error(e.message!!))
        }
    }

    fun getWords(length: Int) = viewModelScope.launch {
        try {
            words.postValue(Resource.Loading())
            words.postValue(Resource.Success(fetchFavoriteWords(repository.getWords(length))))
        } catch (e: Exception) {
            e.printStackTrace()
            words.postValue(Resource.Error(""))
        }
    }

    fun filterWord(index: Int, word: String) = viewModelScope.launch {
        filters.postValue(Resource.Loading())
        delay(200)
        filters.postValue(Resource.Success(fetchFavoriteWords(repository.filterWord(index, word))))
    }

    // favorite
    fun getFavoriteWords() = viewModelScope.launch {
        repository.getFavoriteWords().also {
            if (it.isNotEmpty())
                favoriteWords.postValue(Resource.Success(it))
            else
                favoriteWords.postValue(Resource.Error("Empty favorite words"))
        }
    }

    private suspend fun fetchFavoriteWords(words: List<Word>): List<Word> {
        return words.onEach {
            if (repository.getFavoriteWord(it.word) != null)
                it.isFavorite = true
        }
    }

    //Save state recycler view
    fun saveRecyclerViewState(parcelable: Parcelable) {
        state = parcelable
    }

    fun restoreRecyclerViewState(): Parcelable? = state

    // CRUD favorite
    fun modifyFavoriteWord(word: Word) = viewModelScope.launch {
        val check = word.isFavorite
        val item = convertWordToFav(word)
        when (check) {
            false -> repository.addFavorite(item)
            else -> repository.removeFavorite(item)
        }
    }

    fun removeFavorite(favorite: Favorite) = viewModelScope.launch {
        repository.removeFavorite(favorite)
    }

}