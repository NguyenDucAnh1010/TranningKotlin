package com.example.androidtraining2.data.local.entity.relations

import androidx.room.Embedded
import androidx.room.Junction
import androidx.room.Relation
import com.example.androidtraining2.data.local.entity.QuestionCollection
import com.example.androidtraining2.data.local.entity.Topic
import com.example.androidtraining2.utils.Constants.QUES_COL_PRIMARY_KEY
import com.example.androidtraining2.utils.Constants.TOPIC_PRIMARY_KEY

data class TopicWithQuesCols(
    @Embedded val topic: Topic,
    @Relation(
        parentColumn = TOPIC_PRIMARY_KEY,
        entityColumn = QUES_COL_PRIMARY_KEY,
        associateBy = Junction(QuesColsAndTopics::class)
    )
    val quesCols: List<QuestionCollection>
)
