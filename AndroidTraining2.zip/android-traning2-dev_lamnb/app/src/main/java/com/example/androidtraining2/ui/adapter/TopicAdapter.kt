package com.example.androidtraining2.ui.adapter

import android.content.Context
import com.example.androidtraining2.R
import com.example.androidtraining2.data.local.entity.Topic
import com.example.androidtraining2.databinding.ItemTopicBinding
import com.example.androidtraining2.extension.loadImageUrl
import com.example.androidtraining2.presentation.base.BaseAdapter

class TopicAdapter(
    private val mContext: Context,
    topicList: MutableList<Topic>
) : BaseAdapter<ItemTopicBinding, Topic>(topicList) {
    override val layoutId: Int
        get() = R.layout.item_topic

    override fun bind(binding: ItemTopicBinding, item: Topic, position: Int) {
        binding.apply {
            tvTopic.text = item.topicName
            item.image?.let { ivTopic.loadImageUrl(mContext, it) }
            root.setOnClickListener {
                onItemClick?.let { it(123, item, position) }
            }
        }
    }
}