package com.example.androidtraining2.data.local.dao

import androidx.room.Dao
import androidx.room.Query
import com.example.androidtraining2.data.local.entity.Word
import com.example.androidtraining2.utils.Constants.DISPLAY_LIST

@Dao
interface DictionaryDao : BaseDao<Word> {

    @Query("SELECT * FROM word_tbl LIMIT $DISPLAY_LIST OFFSET :index")
    suspend fun getAllWord(index: Int): List<Word>

    @Query("SELECT * FROM word_tbl LIMIT :length")
    suspend fun getWords(length: Int): List<Word>

    @Query("SELECT * FROM word_tbl WHERE word LIKE :word LIMIT $DISPLAY_LIST OFFSET :index")
    suspend fun filterWord(index: Int, word: String): List<Word>
}