package com.example.androidtraining2.data.local.entity.relations

import androidx.room.Embedded
import androidx.room.Relation
import com.example.androidtraining2.data.local.entity.Question
import com.example.androidtraining2.data.local.entity.Topic
import com.example.androidtraining2.utils.Constants.TOPIC_PRIMARY_KEY

data class TopicWithQuestions(
    @Embedded val topic: Topic,
    @Relation(
        parentColumn = TOPIC_PRIMARY_KEY,
        entityColumn = TOPIC_PRIMARY_KEY
    )
    val questions: List<Question>
)
