package com.example.androidtraining2.data.local.dao

import androidx.room.Dao
import androidx.room.Query
import com.example.androidtraining2.data.local.entity.Favorite

@Dao
interface FavoriteDao : BaseDao<Favorite> {

    @Query("SELECT * FROM favorite")
    suspend fun getFavoriteWords(): List<Favorite>

    @Query("SELECT * FROM favorite WHERE favId=:word")
    suspend fun getFavoriteWord(word: String): Favorite?
}