package com.example.androidtraining2.ui.dialog

import android.app.Activity
import android.app.Dialog
import android.view.LayoutInflater
import androidx.databinding.DataBindingUtil
import com.example.androidtraining2.R
import com.example.androidtraining2.data.local.entity.Word
import com.example.androidtraining2.databinding.DialogCorrectAnswerBinding
import com.example.androidtraining2.databinding.DialogRuleBinding
import com.example.androidtraining2.databinding.DialogShareBinding
import com.example.androidtraining2.databinding.DialogWrongAnswerBinding
import com.example.androidtraining2.extension.setupDialog
import com.example.androidtraining2.extension.shareScreenshot

class DialogView(
    val activity: Activity
) {
    lateinit var shareBinding: DialogShareBinding
    lateinit var ruleBinding: DialogRuleBinding
    private val wrongAnsBinding: DialogWrongAnswerBinding by lazy {
        DataBindingUtil.inflate(
            LayoutInflater.from(activity), R.layout.dialog_wrong_answer, null, false
        )
    }
    private val correctAnsBinding: DialogCorrectAnswerBinding by lazy {
        DataBindingUtil.inflate(
            LayoutInflater.from(activity), R.layout.dialog_correct_answer, null, false
        )
    }

    fun showShareDialog(word: Word) {
        shareBinding = DataBindingUtil.inflate(
            LayoutInflater.from(activity), R.layout.dialog_share, null, false
        )
        Dialog(activity, R.style.Theme_Dialog).also {
            shareBinding.apply {
                tvWord.text = word.word
                tvMean.text = word.mean
                btnShare.setOnClickListener {
                    shareScreenshot(
                        activity,
                        layoutShare,
                        word.word,
                        activity.getString(R.string.intent_message_share, word.word)
                    )
                }
            }
            it.setupDialog(true)
            it.setContentView(shareBinding.root)
            it.show()
        }
    }

    fun showRuleDialog(rule: String, start: () -> Unit, cancel: () -> Unit) {
        ruleBinding = DataBindingUtil.inflate(
            LayoutInflater.from(activity), R.layout.dialog_rule, null, false
        )
        Dialog(activity, R.style.Theme_Dialog).also { dialog ->
            ruleBinding.apply {
                tvRule.text = rule
                btnStart.setOnClickListener {
                    dialog.dismiss()
                    start()
                }
                btnCancel.setOnClickListener {
                    dialog.dismiss()
                    cancel()
                }
            }
            dialog.setupDialog(false)
            dialog.setContentView(ruleBinding.root)
            dialog.show()
        }
    }

    fun showAnswerDialog(
        correct: Boolean,
        yourAns: String?,
        correctAns: String,
        image: String?,
        next: (Dialog) -> Unit
    ) {
        when (correct) {
            true -> {
                Dialog(activity, R.style.Theme_Dialog).also {
                    correctAnsBinding.apply {
                        this.correct = correctAns
                        this.url = image
                    }
                    it.setupDialog(false)
                    it.setContentView(correctAnsBinding.root)
                    it.show()
                    next(it)
                }
            }
            else -> {
                Dialog(activity, R.style.Theme_Dialog).also { dialog ->
                    wrongAnsBinding.apply {
                        this.url = image
                        this.yourAns = yourAns
                        this.correct = correctAns
                        tvNext.setOnClickListener {
                            next(dialog)
                        }
                    }
                    dialog.setupDialog(false)
                    dialog.setContentView(wrongAnsBinding.root)
                    dialog.show()
                }
            }
        }
    }
}