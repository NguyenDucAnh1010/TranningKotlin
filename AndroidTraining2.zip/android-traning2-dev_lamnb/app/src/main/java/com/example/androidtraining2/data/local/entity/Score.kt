package com.example.androidtraining2.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity
data class Score(
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val score: Int,
    val correctAns: Int,
    val totalQues: Int
) : Serializable
