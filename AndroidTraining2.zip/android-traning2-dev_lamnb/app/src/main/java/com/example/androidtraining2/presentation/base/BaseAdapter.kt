package com.example.androidtraining2.presentation.base

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.recyclerview.widget.RecyclerView

abstract class BaseAdapter<BINDING : ViewDataBinding, T>(
    var _data: MutableList<T>,
) : RecyclerView.Adapter<BaseViewHolder<BINDING>>() {

    @get:LayoutRes
    abstract val layoutId: Int

    abstract fun bind(binding: BINDING, item: T, position: Int)

    @SuppressLint("NotifyDataSetChanged")
    open fun setData(list: MutableList<T>) {
        this._data = list
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    open fun appendData(list: MutableList<T>) {
        val oldSize = _data.size
        _data.addAll(list)

        val newSize = _data.size
        _data = _data.toMutableSet().toMutableList()
        notifyItemRangeChanged(oldSize, newSize)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<BINDING> =
        BaseViewHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                layoutId,
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: BaseViewHolder<BINDING>, position: Int) =
        bind(holder.binding, _data[position], position)

    override fun getItemCount(): Int = _data.size

    var onItemClick: ((Int, T, Int) -> Unit)? = null
    fun setOnItemClickListener(listener: (Int, T, Int) -> Unit) {
        onItemClick = listener
    }
}