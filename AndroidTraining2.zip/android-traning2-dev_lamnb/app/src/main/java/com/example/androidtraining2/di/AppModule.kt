package com.example.androidtraining2.di

import android.content.Context
import androidx.room.Room
import com.example.androidtraining2.data.local.DictionaryDatabase
import com.example.androidtraining2.presentation.preference.PreferenceHelper
import com.example.androidtraining2.presentation.preference.PreferenceImpl
import com.example.androidtraining2.utils.Constants.DB_NAME
import com.example.androidtraining2.utils.Constants.DB_PATH
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context
    ) = Room.databaseBuilder(
        context,
        DictionaryDatabase::class.java,
        DB_NAME
    ).createFromAsset(DB_PATH)
        .fallbackToDestructiveMigration()
//        .fallbackToDestructiveMigrationOnDowngrade()
//        .addMigrations(MIGRATION_7_8)
        .build()

    @Provides
    @Singleton
    fun provideDao(db: DictionaryDatabase) = db.dictionaryDao()

    @Provides
    @Singleton
    fun provideFavoriteDao(db: DictionaryDatabase) = db.favoriteDao()

    @Provides
    @Singleton
    fun provideQuesCollectionDao(db: DictionaryDatabase) = db.quesCollectionDao()

    @Provides
    @Singleton
    fun provideTopicDao(db: DictionaryDatabase) = db.topicDao()

    @Provides
    @Singleton
    fun provideQuestionDao(db: DictionaryDatabase) = db.questionDao()

    @Provides
    @Singleton
    fun provideQuesColsAndTopicsDao(db: DictionaryDatabase) =
        db.quesColsAndTopicsDao()

    @Provides
    @Singleton
    fun provideScoreDao(db: DictionaryDatabase) = db.scoreDao()

    @Provides
    @Singleton
    fun providePreference(@ApplicationContext context: Context): PreferenceHelper =
        PreferenceImpl(context)
}