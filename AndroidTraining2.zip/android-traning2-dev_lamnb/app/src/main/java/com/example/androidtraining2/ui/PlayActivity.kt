package com.example.androidtraining2.ui

import android.os.Bundle
import android.view.LayoutInflater
import androidx.databinding.ViewDataBinding
import androidx.navigation.NavOptions
import androidx.navigation.fragment.NavHostFragment
import com.example.androidtraining2.R
import com.example.androidtraining2.databinding.ActivityPlayBinding
import com.example.androidtraining2.presentation.base.BaseActivity
import com.example.androidtraining2.utils.Constants.EXTRA_TYPE
import com.example.androidtraining2.utils.Constants.TYPE_LISTENING
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class PlayActivity : BaseActivity<ActivityPlayBinding>() {

    override val bindingInflater: (LayoutInflater) -> ViewDataBinding
        get() = ActivityPlayBinding::inflate

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val navOptions = NavOptions.Builder()
            .setPopUpTo(R.id.playFragment, true)
            .build()

        val navHost =
            supportFragmentManager.findFragmentById(R.id.fragment2) as NavHostFragment
        val graph = navHost.navController
            .navInflater.inflate(R.navigation.game_graph)

        val navController = navHost.navController
        navController.navigate(R.id.action_playFragment_to_listenFragment, null, navOptions)
        when (intent.getStringExtra(EXTRA_TYPE)) {
            TYPE_LISTENING -> graph.startDestination = R.id.listeningFragment
            else -> graph.startDestination = R.id.playFragment
        }
        navHost.navController.graph = graph
    }

}