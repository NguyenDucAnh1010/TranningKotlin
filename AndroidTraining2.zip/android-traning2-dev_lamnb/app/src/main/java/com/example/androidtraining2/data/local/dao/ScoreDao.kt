package com.example.androidtraining2.data.local.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Query
import com.example.androidtraining2.data.local.entity.Score

@Dao
interface ScoreDao : BaseDao<Score> {
    @Query("SELECT * FROM Score")
    fun getAllScore(): LiveData<List<Score>>
}