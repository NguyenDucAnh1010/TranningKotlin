package com.example.androidtraining2.ui

import android.os.Bundle
import android.view.LayoutInflater
import androidx.activity.viewModels
import androidx.databinding.ViewDataBinding
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.example.androidtraining2.R
import com.example.androidtraining2.data.local.entity.QuestionCollection
import com.example.androidtraining2.databinding.ActivityMainBinding
import com.example.androidtraining2.presentation.base.BaseActivity
import com.example.androidtraining2.ui.viewmodels.GameViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : BaseActivity<ActivityMainBinding>() {

    //    @Inject
//    lateinit var
//
    private val viewModel by viewModels<GameViewModel>()

    override val bindingInflater: (LayoutInflater) -> ViewDataBinding
        get() = ActivityMainBinding::inflate

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        val navHost =
            supportFragmentManager.findFragmentById(R.id.fragment) as NavHostFragment
        val navController = navHost.navController

        binding.bottomMenu.setupWithNavController(navController)
        viewModel.addQuesColl(QuestionCollection("Vocabulary", R.drawable.ic_vocabulary))
        viewModel.addQuesColl(QuestionCollection("Grammar", R.drawable.ic_grammar))
        viewModel.addQuesColl(QuestionCollection("Listening", R.drawable.ic_listening))
        viewModel.addQuesColl(QuestionCollection("Communicate", R.drawable.ic_communicate))
    }

}