package com.example.androidtraining2.data.local.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Query
import com.example.androidtraining2.data.local.entity.Topic

@Dao
interface TopicDao : BaseDao<Topic> {
    @Query("SELECT * FROM topic")
    fun getTopics(): LiveData<List<Topic>>
}