package com.example.androidtraining2.ui.fragment.score

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.androidtraining2.R
import com.example.androidtraining2.databinding.FragmentScoreBinding
import com.example.androidtraining2.extension.requestPermission
import com.example.androidtraining2.extension.shareScore
import com.example.androidtraining2.presentation.base.BaseFragment
import com.example.androidtraining2.ui.PlayActivity
import com.example.androidtraining2.ui.viewmodels.GameViewModel
import com.example.androidtraining2.utils.Constants.FILE_SHARE_SCORE
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ScoreFragment : BaseFragment<FragmentScoreBinding>() {

    private val viewModel by activityViewModels<GameViewModel>()
    private val args by navArgs<ScoreFragmentArgs>()

    override val bindingInflater: (LayoutInflater) -> ViewDataBinding
        get() = FragmentScoreBinding::inflate


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            this.score = args.score
            this.topic = args.topic
            this.type = args.type
            btnPlayAgain.setOnClickListener {
                findNavController().navigateUp()
            }
            btnBackHome.setOnClickListener {
                (activity as PlayActivity).finish()
            }
            btnShare.setOnClickListener {
                requestPermission {
                    shareScore(
                        activity as PlayActivity,
                        layoutScore,
                        FILE_SHARE_SCORE,
                        getString(R.string.share_score)
                    )
                }
            }
        }


    }

}