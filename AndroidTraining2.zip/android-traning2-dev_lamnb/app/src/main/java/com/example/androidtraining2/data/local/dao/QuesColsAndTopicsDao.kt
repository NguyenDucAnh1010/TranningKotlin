package com.example.androidtraining2.data.local.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Transaction
import com.example.androidtraining2.data.local.entity.relations.QuesColWithTopics

@Dao
interface QuesColsAndTopicsDao {

    @Transaction
    @Query("SELECT * FROM question_collection WHERE quesColName=:quesColName")
    suspend fun getTopicsOfQuesCol(quesColName: String): QuesColWithTopics
}