package com.example.androidtraining2.ui.fragment.game

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.androidtraining2.R
import com.example.androidtraining2.data.local.entity.Topic
import com.example.androidtraining2.databinding.FragmentTopicBinding
import com.example.androidtraining2.extension.handleMutableLiveData
import com.example.androidtraining2.extension.setupGridAdapter
import com.example.androidtraining2.extension.showToast
import com.example.androidtraining2.extension.startToActivity
import com.example.androidtraining2.presentation.base.BaseFragment
import com.example.androidtraining2.ui.PlayActivity
import com.example.androidtraining2.ui.adapter.TopicAdapter
import com.example.androidtraining2.ui.viewmodels.GameViewModel
import com.example.androidtraining2.utils.Constants.EXTRA_TOPIC
import com.example.androidtraining2.utils.Constants.EXTRA_TYPE
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TopicFragment : BaseFragment<FragmentTopicBinding>() {

    private val viewModel by activityViewModels<GameViewModel>()
    private val args by navArgs<TopicFragmentArgs>()
    lateinit var adapter: TopicAdapter

    override val bindingInflater: (LayoutInflater) -> ViewDataBinding
        get() = FragmentTopicBinding::inflate

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.getTopicOfQuesCol(args.quesCol.quesColName)
        handleMutableLiveData(viewModel.topics, null) {
            adapter.setData(it.topics as MutableList<Topic>)
        }
        binding.btnBack.setOnClickListener {
            findNavController().navigateUp()
        }
        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        adapter = TopicAdapter(requireContext(), mutableListOf())
        binding.rvTopics.setupGridAdapter(requireContext(), adapter)
        adapter.setOnItemClickListener { _, item, _ ->
            viewModel.getQuestions(item.topicName, args.quesCol.quesColName)
                .observe(viewLifecycleOwner) {
                    if (it.isNotEmpty()) {
                        startToActivity(PlayActivity::class.java) {
                            putExtra(EXTRA_TYPE, args.quesCol.quesColName)
                            putExtra(EXTRA_TOPIC, item)
                        }
                    } else
                        showToast(getString(R.string.empty_question))
                }
        }
    }

}