package com.example.androidtraining2.presentation.preference

import android.content.Context
import android.content.SharedPreferences
import com.example.androidtraining2.utils.Constants.PREF_FILE_NAME
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PreferenceImpl @Inject constructor(context: Context) : PreferenceHelper {

    private val mPrefs: SharedPreferences =
        context.getSharedPreferences(PREF_FILE_NAME, Context.MODE_PRIVATE)

    private val editor = mPrefs.edit()

    override fun saveSpeedSpeak(prefName: String, prefValue: Float) {
        editor.putFloat(prefName, prefValue)
        editor.apply()
    }

    override fun saveFontSize(prefName: String, prefValue: String) {
        editor.putString(prefName, prefValue)
        editor.apply()
    }

    override fun readSpeedSpeak(prefName: String, defValue: Float): Float =
        mPrefs.getFloat(prefName, defValue)

    override fun readFontSize(prefName: String, defValue: String): String? =
        mPrefs.getString(prefName, defValue)
}