package com.example.androidtraining2.ui.fragment.game

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.example.androidtraining2.R
import com.example.androidtraining2.data.local.entity.Question
import com.example.androidtraining2.data.local.entity.Score
import com.example.androidtraining2.data.local.entity.Topic
import com.example.androidtraining2.databinding.FragmentPlayBinding
import com.example.androidtraining2.extension.*
import com.example.androidtraining2.presentation.base.BaseFragment
import com.example.androidtraining2.ui.PlayActivity
import com.example.androidtraining2.ui.dialog.DialogView
import com.example.androidtraining2.ui.viewmodels.GameViewModel
import com.example.androidtraining2.utils.Constants
import com.example.androidtraining2.utils.Constants.BUNDLE_SCORE
import com.example.androidtraining2.utils.Constants.BUNDLE_TOPIC
import com.example.androidtraining2.utils.Constants.BUNDLE_TYPE
import com.example.androidtraining2.utils.Constants.EXTRA_TOPIC
import com.example.androidtraining2.utils.Constants.EXTRA_TYPE
import com.example.androidtraining2.utils.Constants.INCREASE_SCORE
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*

@AndroidEntryPoint
class PlayFragment : BaseFragment<FragmentPlayBinding>() {

    private val viewModel by activityViewModels<GameViewModel>()
    override val bindingInflater: (LayoutInflater) -> ViewDataBinding
        get() = FragmentPlayBinding::inflate

    lateinit var topic: Topic
    lateinit var type: String

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.root.visibility = View.GONE
        topic = getObjectExtra(activity as PlayActivity, EXTRA_TOPIC) as Topic
        type = (activity as PlayActivity).intent.getStringExtra(EXTRA_TYPE).toString()
        viewModel.setupDelayTimeQuestion(type)
        viewModel.getQuestions(topic.topicName, type).observe(viewLifecycleOwner) {
            questions = it
            DialogView(activity as PlayActivity).also { dialog ->
                dialog.showRuleDialog(getString(
                    R.string.dialog_game_rule,
                    questions.size.toString(),
                    viewModel.time.toString(),
                    INCREASE_SCORE.toString()
                ), {
                    binding.root.visibility = View.VISIBLE
                    initStartPlay()
                }, {
                    (activity as PlayActivity).finish()
                })
            }
        }

        binding.btnBack.setOnClickListener {
            onBackPress()
        }
        handleBackPress {
            onBackPress()
        }
    }

    private var questions = listOf<Question>()

    private fun initStartPlay() {
        binding.tvQuesNumber.text =
            getString(
                R.string.question_number,
                (viewModel.pos + 1).toString(),
                questions.size.toString()
            )
        binding.tvScore.text = getString(R.string.score, viewModel.score.toString())
        binding.tvTime.text = viewModel.time.toString()
        displayQuestion(viewModel.pos)
        countTime()
    }

    private var count: Job? = null
    private fun countTime() {
        count = lifecycleScope.launch {
            do {
                delay(1000)
                viewModel.time--
                withContext(Dispatchers.Main) {
                    binding.tvTime.text = viewModel.time.toString()
                }
            } while (viewModel.time != 0)
            delay(1000)
            if (viewModel.time == 0) {
                vibratePhone(requireContext())
                DialogView(activity as PlayActivity).also {
                    it.showAnswerDialog(
                        false,
                        getString(R.string.no_answer),
                        questions[viewModel.pos].correctAns,
                        questions[viewModel.pos].image
                    ) { dialog ->
                        dialog.dismiss()
                        nextQuestion()
                    }
                }
            }
        }
    }

    private fun displayQuestion(index: Int) {
        lifecycleScope.launch(Dispatchers.Main) {
            binding.apply {
                tvQuestion.text = questions[index].quesName
                btnA.text = questions[index].caseA
                btnB.text = questions[index].caseB
                btnC.text = questions[index].caseC
                btnD.text = questions[index].caseD
                btnA.click()
                btnB.click()
                btnC.click()
                btnD.click()
            }
        }
    }

    private fun nextQuestion() {
        viewModel.pos++
        if (viewModel.pos == questions.size) {
            navigate(R.id.action_playFragment_to_scoreFragment) {
                putSerializable(
                    BUNDLE_SCORE,
                    Score(0, viewModel.score, viewModel.correctAns, questions.size)
                )
                putSerializable(BUNDLE_TOPIC, topic)
                putString(BUNDLE_TYPE, type)
            }
            return
        }
        viewModel.setupDelayTimeQuestion(type)
        initStartPlay()
    }

    private fun Button.click() {
        setOnClickListener {
            if (viewModel.pos == questions.size)
                return@setOnClickListener
            count?.cancel()
            when (text == getCorrectAnswer(questions[viewModel.pos].correctAns)) {
                true -> {
                    correctSound(requireContext())
                    viewModel.plusPoint()
                    DialogView(activity as PlayActivity).also {
                        it.showAnswerDialog(
                            true, null, questions[viewModel.pos].correctAns,
                            questions[viewModel.pos].image
                        ) { dialog ->
                            lifecycleScope.launch(Dispatchers.Main) {
                                delay(Constants.TIME_SHOW_ANSWER)
                                dialog.dismiss()
                                nextQuestion()
                            }
                        }
                    }
                }
                else -> {
                    vibratePhone(requireContext())
                    DialogView(activity as PlayActivity).also {
                        it.showAnswerDialog(
                            false,
                            text.toString(),
                            questions[viewModel.pos].correctAns,
                            questions[viewModel.pos].image
                        ) { dialog ->
                            dialog.dismiss()
                            nextQuestion()
                        }
                    }
                }
            }

        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.resetPlay()
    }
}