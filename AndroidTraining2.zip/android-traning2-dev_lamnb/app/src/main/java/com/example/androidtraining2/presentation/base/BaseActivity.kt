package com.example.androidtraining2.presentation.base

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.ViewDataBinding
import com.example.androidtraining2.R
import com.example.androidtraining2.extension.displayDialog
import com.example.androidtraining2.extension.requirePermission
import com.example.androidtraining2.extension.showToast
import com.example.androidtraining2.presentation.preference.PreferenceHelper
import javax.inject.Inject

abstract class BaseActivity<B : ViewDataBinding?> : AppCompatActivity() {

    @Inject
    lateinit var prefHelper: PreferenceHelper

    private var _binding: ViewDataBinding? = null

    @Suppress("UNCHECKED_CAST")
    protected val binding: B
        get() = _binding as B

    @Suppress("UNCHECKED_CAST")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = bindingInflater(layoutInflater) as B
    }

    protected abstract val bindingInflater: (LayoutInflater) -> ViewDataBinding

    var requestListener: (() -> Unit)? = null

    @RequiresApi(Build.VERSION_CODES.N)
    val requestMultiplePermissions =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            permissions.forEach { (s, _) ->
                if (permissions[s] == false) {
                    if (!shouldShowRequestPermissionRationale(s)) {
                        displayDialog(this,
                            title = getString(R.string.dialog_attention),
                            message = getString(
                                R.string.dialog_require_permission
                            ),
                            accept = getString(R.string.dialog_accept),
                            cancel = getString(R.string.dialog_cancel),
                            positiveListener = { _, _ ->
                                requirePermission(this)
                            },
                            negativeListener = { _, _ ->
                                showToast(getString(R.string.error_permission_denied))
                            }
                        )
                        return@registerForActivityResult
                    }
                }
            }
            requestListener?.let { it() }
        }
}