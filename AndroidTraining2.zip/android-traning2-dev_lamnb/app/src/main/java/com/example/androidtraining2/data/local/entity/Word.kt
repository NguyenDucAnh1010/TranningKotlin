package com.example.androidtraining2.data.local.entity

import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "word_tbl")
data class Word(
    @PrimaryKey
    val word: String,
    val av: ByteArray?,
    val dnpn: ByteArray?,
    val aa: ByteArray?,
    val mean: String?
) : Serializable {
    @Ignore
    var isFavorite: Boolean = false
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Word

        if (word != other.word) return false
        if (av != null) {
            if (other.av == null) return false
            if (!av.contentEquals(other.av)) return false
        } else if (other.av != null) return false
        if (dnpn != null) {
            if (other.dnpn == null) return false
            if (!dnpn.contentEquals(other.dnpn)) return false
        } else if (other.dnpn != null) return false
        if (aa != null) {
            if (other.aa == null) return false
            if (!aa.contentEquals(other.aa)) return false
        } else if (other.aa != null) return false
        if (mean != other.mean) return false
        if (isFavorite != other.isFavorite) return false

        return true
    }

    override fun hashCode(): Int {
        var result = word.hashCode()
        result = 31 * result + (av?.contentHashCode() ?: 0)
        result = 31 * result + (dnpn?.contentHashCode() ?: 0)
        result = 31 * result + (aa?.contentHashCode() ?: 0)
        result = 31 * result + (mean?.hashCode() ?: 0)
        result = 31 * result + isFavorite.hashCode()
        return result
    }
}