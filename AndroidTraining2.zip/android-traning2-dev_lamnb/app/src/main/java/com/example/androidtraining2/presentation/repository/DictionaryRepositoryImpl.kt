package com.example.androidtraining2.presentation.repository

import android.app.Application
import androidx.lifecycle.LiveData
import com.example.androidtraining2.data.local.dao.*
import com.example.androidtraining2.data.local.entity.*
import com.example.androidtraining2.data.local.entity.relations.QuesColWithTopics
import com.example.androidtraining2.data.local.entity.relations.TopicWithQuestions
import dagger.hilt.android.scopes.ViewModelScoped
import javax.inject.Inject

@ViewModelScoped
class DictionaryRepositoryImpl @Inject constructor(
    val app: Application,
    private val dictionaryDao: DictionaryDao,
    private val favoriteDao: FavoriteDao,
    private val quesCollectionDao: QuesCollectionDao,
    private val topicDao: TopicDao,
    private val questionDao: QuestionDao,
    private val quesColTopicDao: QuesColsAndTopicsDao,
    private val scoreDao: ScoreDao
) : DictionaryRepository {
    // local
    override suspend fun getAllWord(index: Int) = dictionaryDao.getAllWord(index)

    override suspend fun getWords(length: Int) = dictionaryDao.getWords(length)

    override suspend fun filterWord(index: Int, word: String): List<Word> =
        dictionaryDao.filterWord(index, word)

    // favorite
    override suspend fun addFavorite(favorite: Favorite) = favoriteDao.insert(favorite)

    override suspend fun removeFavorite(favorite: Favorite) = favoriteDao.delete(favorite)

    override suspend fun getFavoriteWords() = favoriteDao.getFavoriteWords()

    override suspend fun getFavoriteWord(word: String) = favoriteDao.getFavoriteWord(word)

    // game
    override suspend fun addQuesColl(quesCollection: QuestionCollection) =
        quesCollectionDao.insert(quesCollection)

    override fun getQuestionCollections() = quesCollectionDao.getQuestionCollections()

    override suspend fun addTopic(vararg topic: Topic) = topicDao.insertAll(*topic)

    override fun getTopics(): LiveData<List<Topic>> = topicDao.getTopics()

    override suspend fun addQuestion(vararg question: Question) = questionDao.insertAll(*question)

    override fun getQuestions(topicName: String, type: String): LiveData<List<Question>> =
        questionDao.getQuestions(topicName, type)

    override suspend fun getTopicsOfQuesCol(quesColName: String): QuesColWithTopics =
        quesColTopicDao.getTopicsOfQuesCol(quesColName)

    override fun getQuestionsOfTopic(topicName: String): LiveData<TopicWithQuestions> =
        questionDao.getQuestionsOfTopic(topicName)

    //Score
    override suspend fun addScore(score: Score) = scoreDao.insert(score)

    override fun getAllScore(): LiveData<List<Score>> = scoreDao.getAllScore()
}