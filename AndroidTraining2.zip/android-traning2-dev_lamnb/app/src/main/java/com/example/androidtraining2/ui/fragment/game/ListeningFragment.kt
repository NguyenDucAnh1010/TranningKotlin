package com.example.androidtraining2.ui.fragment.game

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.example.androidtraining2.R
import com.example.androidtraining2.data.local.entity.Question
import com.example.androidtraining2.data.local.entity.Score
import com.example.androidtraining2.data.local.entity.Topic
import com.example.androidtraining2.databinding.FragmentListeningBinding
import com.example.androidtraining2.extension.*
import com.example.androidtraining2.presentation.base.BaseFragment
import com.example.androidtraining2.ui.PlayActivity
import com.example.androidtraining2.ui.dialog.DialogView
import com.example.androidtraining2.ui.viewmodels.GameViewModel
import com.example.androidtraining2.utils.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ListeningFragment : BaseFragment<FragmentListeningBinding>() {

    private val viewModel by activityViewModels<GameViewModel>()

    override val bindingInflater: (LayoutInflater) -> ViewDataBinding
        get() = FragmentListeningBinding::inflate

    lateinit var topic: Topic
    lateinit var type: String

    private var questions = listOf<Question>()
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.root.visibility = View.GONE
        topic = getObjectExtra(activity as PlayActivity, Constants.EXTRA_TOPIC) as Topic
        type = (activity as PlayActivity).intent.getStringExtra(Constants.EXTRA_TYPE).toString()
        viewModel.getQuestions(topic.topicName, type).observe(viewLifecycleOwner) {
            questions = it
            DialogView(activity as PlayActivity).also { dialog ->
                dialog.showRuleDialog(getString(
                    R.string.dialog_game_rule_listening,
                    questions.size.toString(),
                    Constants.INCREASE_SCORE.toString()
                ), {
                    binding.root.visibility = View.VISIBLE
                    initStartPlay()
                }, {
                    (activity as PlayActivity).finish()
                })
            }
        }

        binding.btnBack.setOnClickListener {
            onBackPress()
        }
        handleBackPress {
            onBackPress()
        }
    }

    private fun initStartPlay() {
        binding.tvQuesNumber.text =
            getString(
                R.string.question_number,
                (viewModel.pos + 1).toString(),
                questions.size.toString()
            )
        binding.tvScore.text = getString(R.string.score, viewModel.score.toString())
        binding.etAnswer.text.clear()
        displayQuestion(viewModel.pos)
    }
    var tts: TextToSpeech? = null
    private fun displayQuestion(index: Int) {
        //speakWord(requireContext(), questions[viewModel.pos].caseA, 1f)
        lifecycleScope.launch {
            delay(1000)
            tts = speak(questions[viewModel.pos].caseA)
        }
        binding.apply {
            tvQuestion.text = questions[index].quesName
            btnListen.setOnClickListener {
                tts?.shutdown()
                tts = speak(questions[viewModel.pos].caseA)
                viewModel.checkListen()
            }
            tvCheck.check()
        }
    }

    private fun TextView.check() {
        setOnClickListener {
            val answer = binding.etAnswer.text.toString()
            if(answer.isEmpty() && !viewModel.isListened)
            {
                showToast(context.getString(R.string.check_answer_listening))
                return@setOnClickListener
            }
            when (answer.lowercase().trim().contains(
                questions[viewModel.pos].correctAns.lowercase()
                    .trim()
            )) {
                true -> {
                    correctSound(requireContext())
                    viewModel.plusPoint()
                    DialogView(activity as PlayActivity).also {
                        it.showAnswerDialog(
                            true, null, answer,
                            questions[viewModel.pos].image
                        ) { dialog ->
                            lifecycleScope.launch(Dispatchers.Main) {
                                delay(Constants.TIME_SHOW_ANSWER)
                                dialog.dismiss()
                                nextQuestion()
                            }
                        }
                    }
                }
                else -> {
                    vibratePhone(requireContext())
                    DialogView(activity as PlayActivity).also {
                        it.showAnswerDialog(
                            false,
                            if(answer.isEmpty()) context.getString(R.string.empty_answer)
                            else binding.etAnswer.text.toString(),
                            questions[viewModel.pos].correctAns,
                            questions[viewModel.pos].image
                        ) { dialog ->
                            dialog.dismiss()
                            nextQuestion()
                        }
                    }
                }
            }
        }
    }

    private fun nextQuestion() {
        tts?.shutdown()
        tts = null
        viewModel.isListened = false
        viewModel.pos++
        if (viewModel.pos == questions.size) {
            navigate(R.id.action_listenFragment_to_scoreFragment) {
                putSerializable(
                    Constants.BUNDLE_SCORE,
                    Score(0, viewModel.score, viewModel.correctAns, questions.size)
                )
                putSerializable(Constants.BUNDLE_TOPIC, topic)
                putString(Constants.BUNDLE_TYPE, type)
            }
            return
        }
        initStartPlay()
    }

    override fun onStop() {
        super.onStop()
        tts?.let {
            tts?.stop()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.resetPlay()
    }
}