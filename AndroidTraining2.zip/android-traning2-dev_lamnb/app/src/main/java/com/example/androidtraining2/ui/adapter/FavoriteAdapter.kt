package com.example.androidtraining2.ui.adapter

import com.example.androidtraining2.R
import com.example.androidtraining2.data.local.entity.Favorite
import com.example.androidtraining2.databinding.ItemWordBinding
import com.example.androidtraining2.extension.adjustFontSize
import com.example.androidtraining2.presentation.base.BaseAdapter
import com.example.androidtraining2.presentation.preference.PreferenceHelper

class FavoriteAdapter(
    wordList: MutableList<Favorite>,
    private val pref: PreferenceHelper
) : BaseAdapter<ItemWordBinding, Favorite>(wordList) {

    override val layoutId: Int
        get() = R.layout.item_word

    override fun bind(binding: ItemWordBinding, item: Favorite, position: Int) {
        binding.apply {
            tvWord.text = item.favId
            tvMean.text = item.mean
            root.adjustFontSize(pref, tvWord, tvMean)
            btnFavorite.setImageResource(R.drawable.ic_select_favorite)

            btnSpeak.setOnClickListener {
                onItemClick?.let { it(R.id.btnSpeak, item, position) }
            }
            btnFavorite.setOnClickListener {
                onItemClick?.let { it(R.id.btnFavorite, item, position) }
            }
            btnShare.setOnClickListener {
                onItemClick?.let { it(R.id.btnShare, item, position) }
            }
            root.setOnClickListener {
                onItemClick?.let { it(123, item, position) }
            }
        }
    }
}