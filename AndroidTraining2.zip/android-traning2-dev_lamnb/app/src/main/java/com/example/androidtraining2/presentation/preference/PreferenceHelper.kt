package com.example.androidtraining2.presentation.preference

interface PreferenceHelper {

    fun saveSpeedSpeak(prefName: String, prefValue: Float)

    fun saveFontSize(prefName: String, prefValue: String)

    fun readSpeedSpeak(prefName: String, defValue: Float): Float

    fun readFontSize(prefName: String, defValue: String): String?
}