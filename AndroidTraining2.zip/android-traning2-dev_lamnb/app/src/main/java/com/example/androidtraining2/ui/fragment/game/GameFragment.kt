package com.example.androidtraining2.ui.fragment.game

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.activityViewModels
import com.example.androidtraining2.R
import com.example.androidtraining2.data.local.entity.QuestionCollection
import com.example.androidtraining2.databinding.FragmentGameBinding
import com.example.androidtraining2.extension.navigate
import com.example.androidtraining2.extension.setupAdapter
import com.example.androidtraining2.presentation.base.BaseFragment
import com.example.androidtraining2.ui.adapter.QuestionCollectionAdapter
import com.example.androidtraining2.ui.viewmodels.GameViewModel
import com.example.androidtraining2.utils.Constants.BUNDLE_QUES_COL
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class GameFragment : BaseFragment<FragmentGameBinding>() {

    private val viewModel by activityViewModels<GameViewModel>()
    private lateinit var adapter: QuestionCollectionAdapter

    override val bindingInflater: (LayoutInflater) -> ViewDataBinding
        get() = FragmentGameBinding::inflate

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.questionCollections.observe(viewLifecycleOwner) {
            adapter.setData(it as MutableList<QuestionCollection>)
        }
        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        adapter = QuestionCollectionAdapter(mutableListOf())
        binding.rvQuestionCollection.setupAdapter(requireContext(), adapter)
        adapter.setOnItemClickListener { _, item, _ ->
            navigate(R.id.action_gameFragment_to_topicFragment, BUNDLE_QUES_COL, item)
        }
    }
}