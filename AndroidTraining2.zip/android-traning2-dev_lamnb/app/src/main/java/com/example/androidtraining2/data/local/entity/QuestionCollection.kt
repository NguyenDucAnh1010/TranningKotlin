package com.example.androidtraining2.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "question_collection")
data class QuestionCollection(
    @PrimaryKey
    val quesColName: String,
    val image: Int
) : Serializable