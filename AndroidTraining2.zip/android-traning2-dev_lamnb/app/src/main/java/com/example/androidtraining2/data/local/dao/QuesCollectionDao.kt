package com.example.androidtraining2.data.local.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Query
import com.example.androidtraining2.data.local.entity.QuestionCollection

@Dao
interface QuesCollectionDao : BaseDao<QuestionCollection> {

    @Query("SELECT * FROM question_collection")
    fun getQuestionCollections(): LiveData<List<QuestionCollection>>
}