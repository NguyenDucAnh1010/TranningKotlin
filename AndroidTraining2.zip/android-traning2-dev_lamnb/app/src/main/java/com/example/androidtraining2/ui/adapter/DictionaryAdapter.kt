package com.example.androidtraining2.ui.adapter

import com.example.androidtraining2.R
import com.example.androidtraining2.data.local.entity.Word
import com.example.androidtraining2.databinding.ItemWordBinding
import com.example.androidtraining2.extension.adjustFontSize
import com.example.androidtraining2.presentation.base.BaseAdapter
import com.example.androidtraining2.presentation.preference.PreferenceHelper

class DictionaryAdapter(
    wordList: MutableList<Word>,
    private val pref: PreferenceHelper
) : BaseAdapter<ItemWordBinding, Word>(wordList) {

    override val layoutId: Int
        get() = R.layout.item_word

    override fun bind(binding: ItemWordBinding, item: Word, position: Int) {
        binding.apply {
            tvWord.text = item.word
            tvMean.text = item.mean
            root.adjustFontSize(pref, tvWord, tvMean)
            btnFavorite.setImageResource(
                if (item.isFavorite)
                    R.drawable.ic_select_favorite
                else
                    R.drawable.ic_unselect_favorite
            )

            btnSpeak.setOnClickListener {
                onItemClick?.let { it(R.id.btnSpeak, item, position) }
            }
            btnFavorite.setOnClickListener {
                onItemClick?.let { it(R.id.btnFavorite, item, position) }
            }
            btnShare.setOnClickListener {
                onItemClick?.let { it(R.id.btnShare, item, position) }
            }
            root.setOnClickListener {
                onItemClick?.let { it(123, item, position) }
            }
        }
    }
}