package com.example.androidtraining2.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.androidtraining2.R
import com.example.androidtraining2.data.local.entity.QuestionCollection
import com.example.androidtraining2.data.local.entity.relations.QuesColWithTopics
import com.example.androidtraining2.data.local.entity.relations.TopicWithQuestions
import com.example.androidtraining2.presentation.repository.DictionaryRepositoryImpl
import com.example.androidtraining2.utils.Constants.DELAY_TIME_QUESTION
import com.example.androidtraining2.utils.Constants.DELAY_TIME_QUESTION_COMMUNICATE
import com.example.androidtraining2.utils.Constants.INCREASE_SCORE
import com.example.androidtraining2.utils.Constants.TYPE_COMMUNICATE
import com.example.androidtraining2.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class GameViewModel @Inject constructor(
    private val app: Application,
    private val repository: DictionaryRepositoryImpl
) : AndroidViewModel(app) {

    val questionCollections = repository.getQuestionCollections()
    val topics = MutableLiveData<Resource<QuesColWithTopics>>()
    val questions = MutableLiveData<Resource<TopicWithQuestions>>()

    var time = 0
    var pos = 0
    var score = 0
    var correctAns = 0
    var isListened = false

    fun setupDelayTimeQuestion(type: String) {
        time = when (type) {
            TYPE_COMMUNICATE -> DELAY_TIME_QUESTION_COMMUNICATE
            else -> DELAY_TIME_QUESTION
        }
    }

    fun getTopicOfQuesCol(quesColName: String) = viewModelScope.launch {
        try {
            topics.postValue(
                Resource.Success(repository.getTopicsOfQuesCol(quesColName))
            )
        } catch (e: Exception) {
            topics.postValue(
                Resource.Error(app.getString(R.string.empty_list_topic))
            )
        }
    }

    fun getQuestions(topicName: String, type: String) = repository.getQuestions(topicName, type)

    fun addQuesColl(ques: QuestionCollection) = viewModelScope.launch {
        repository.addQuesColl(ques)
    }


    fun plusPoint() {
        score += INCREASE_SCORE
        correctAns += 1
    }

    fun checkListen() {
        isListened = true
    }

    fun resetPlay() {
        pos = 0
        score = 0
        correctAns = 0
    }
}