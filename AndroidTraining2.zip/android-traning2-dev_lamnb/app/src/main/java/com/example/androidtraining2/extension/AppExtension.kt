package com.example.androidtraining2.extension

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.observe
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.example.androidtraining2.R
import com.example.androidtraining2.data.local.entity.Favorite
import com.example.androidtraining2.data.local.entity.Word
import com.example.androidtraining2.presentation.base.BaseAdapter
import com.example.androidtraining2.presentation.base.BaseFragment
import com.example.androidtraining2.presentation.preference.PreferenceHelper
import com.example.androidtraining2.ui.MainActivity
import com.example.androidtraining2.ui.PlayActivity
import com.example.androidtraining2.ui.adapter.DictionaryAdapter
import com.example.androidtraining2.ui.dialog.DialogView
import com.example.androidtraining2.ui.viewmodels.DictionaryViewModel
import com.example.androidtraining2.utils.Constants
import com.example.androidtraining2.utils.Constants.PREF_SPEED_SPEAK
import com.example.androidtraining2.utils.Constants.SCHEMA_PACKAGE
import com.example.androidtraining2.utils.Constants.TIME_VIBRATE
import com.example.androidtraining2.utils.Constants.VALUE_FONT_SIZE_LARGE
import com.example.androidtraining2.utils.Constants.VALUE_FONT_SIZE_NORMAL
import com.example.androidtraining2.utils.Constants.VALUE_FONT_SIZE_SMALL
import com.example.androidtraining2.utils.Constants.VALUE_SPEED_SPEAK
import com.example.androidtraining2.utils.Resource
import java.io.Serializable
import java.text.DecimalFormat
import java.util.*


fun RecyclerView.setupAdapter(context: Context, adapter: BaseAdapter<*, *>) {
    this.adapter = adapter
    this.layoutManager = LinearLayoutManager(context)
}

fun RecyclerView.setupGridAdapter(context: Context, adapter: BaseAdapter<*, *>) {
    this.adapter = adapter
    this.layoutManager = GridLayoutManager(context, 2)
}

fun Fragment.showToast(message: String) {
    Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
}

fun AppCompatActivity.setupActionBar(toolbar: Toolbar?, title: String, showBackButton: Boolean) {
    this.setSupportActionBar(toolbar)
    this.supportActionBar?.title = title
    this.supportActionBar?.setDisplayHomeAsUpEnabled(showBackButton)
}

fun AppCompatActivity.showToast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

fun ImageView.loadImageUrl(context: Context, url: String) {
    val reqOpt = RequestOptions
        .fitCenterTransform()
        .transform(RoundedCorners(5))
        .diskCacheStrategy(DiskCacheStrategy.ALL)
        .override(this.width, this.height)
    Glide.with(context)
        .load(url)
        .apply(reqOpt)
        .error(R.drawable.load_image_error)
        .into(this)
}

fun showProgressBar(show: Boolean, progressBar: ProgressBar) {
    progressBar.visibility = if (show) View.VISIBLE else View.GONE
}

fun speakWord(context: Context, word: String, speed: Float) {
    var tts: TextToSpeech? = null
    try {
        tts = TextToSpeech(context) {
            if (it == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                tts?.setSpeechRate(speed)
                tts?.speak(word, TextToSpeech.QUEUE_ADD, null, null)
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

fun Fragment.speak(word: String): TextToSpeech {
    var tts: TextToSpeech? = null
    tts = TextToSpeech(requireContext()) {
        if (it == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            tts?.speak(word, TextToSpeech.QUEUE_ADD, null, null)
        }
    }
    return tts
}

fun <T> MutableLiveData<T>.observeOnce(lifecycleOwner: LifecycleOwner, observer: Observer<T>) {
    observe(lifecycleOwner, object : Observer<T> {
        override fun onChanged(t: T) {
            observer.onChanged(t)
            removeObserver(this)
        }
    })
}

fun Dialog.setupDialog(cancelable: Boolean) {
    window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    window?.setLayout(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
    )
    requestWindowFeature(Window.FEATURE_NO_TITLE)
    setCancelable(cancelable)
}

fun displayDialog(
    context: Context,
    title: String,
    message: String,
    accept: String,
    cancel: String,
    positiveListener: ((DialogInterface, Int) -> Unit)?,
    negativeListener: ((DialogInterface, Int) -> Unit)?
) {
    AlertDialog.Builder(context).also {
        it.setTitle(title)
            .setMessage(message)
            .setPositiveButton(accept, positiveListener)
            .setNegativeButton(cancel, negativeListener)
            .create()
        it.show()
    }
}

fun animation(): NavOptions {
    return NavOptions.Builder().apply {
        setEnterAnim(R.anim.slide_in_right)
        setExitAnim(R.anim.slide_out_left)
        setPopEnterAnim(R.anim.slide_in_left)
        setPopExitAnim(R.anim.slide_out_right)
    }.build()
}

fun Fragment.startToActivity(cls: Class<*>, putData: Intent.() -> Unit = {}) {
    startActivity(Intent(requireContext(), cls).apply(putData))
}

fun getObjectExtra(ac: Activity, key: String?): Serializable? {
    return ac.intent.getSerializableExtra(key)
}

fun <T> Fragment.navigate(action: Int, key: String?, data: T?) {
    if (key != null) {
        val bundle = Bundle().apply {
            putSerializable(key, data as Serializable?)
        }
        findNavController().navigate(action, bundle, animation())
    } else {
        findNavController().navigate(action, null, animation())
    }
}

fun Fragment.navigate(action: Int, putData: Bundle.() -> Unit = {}) {
    findNavController().navigate(action, Bundle().apply(putData), animation())
}

fun Fragment.handleBackPress(backPress: () -> Unit) {
    activity?.onBackPressedDispatcher?.addCallback(
        viewLifecycleOwner,
        object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                backPress()
            }
        })
}

fun requirePermission(context: Context) {
    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).also {
        it.addCategory(Intent.CATEGORY_DEFAULT)
        val uri = Uri.fromParts(SCHEMA_PACKAGE, context.packageName, null)
        it.data = uri
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        it.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
        it.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        context.startActivity(it)
    }
}

fun formatFloat(num: Float): String {
    if (num < 0.1f) {
        return "0.1"
    }
    return DecimalFormat("#.#").format(num).replace(",", ".")
}

fun SeekBar.setupAdjustSpeed(
    pref: PreferenceHelper,
    changed: (SeekBar?, Int, Boolean) -> Unit,
    start: ((SeekBar?) -> Unit)?,
    stop: ((SeekBar?) -> Unit)?
) {
    incrementProgressBy(10)
    progress = (pref.readSpeedSpeak(PREF_SPEED_SPEAK, VALUE_SPEED_SPEAK) * 50).toInt()
    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
            changed(p0, p1, p2)
        }

        override fun onStartTrackingTouch(p0: SeekBar?) {
            start?.let { it(p0) }
        }

        override fun onStopTrackingTouch(seekBar: SeekBar?) {
            stop?.let {
                stop(seekBar)
            }
        }
    })
}

fun TextView.setupAdjustFontSize(pref: PreferenceHelper, vararg size: Float?) {
    when (pref.readFontSize(Constants.PREF_FONT_SIZE, VALUE_FONT_SIZE_NORMAL)) {
        VALUE_FONT_SIZE_SMALL -> setTextSize(
            TypedValue.COMPLEX_UNIT_SP,
            size[0] ?: resources.getInteger(R.integer.detail_font_size_small).toFloat()
        )
        VALUE_FONT_SIZE_NORMAL -> setTextSize(
            TypedValue.COMPLEX_UNIT_SP,
            size[1] ?: resources.getInteger(R.integer.detail_font_size_normal).toFloat()//
        )
        VALUE_FONT_SIZE_LARGE -> setTextSize(
            TypedValue.COMPLEX_UNIT_SP,
            size[2] ?: resources.getInteger(R.integer.detail_font_size_large).toFloat()//
        )
        else -> setTextSize(
            TypedValue.COMPLEX_UNIT_SP,
            size[3] ?: resources.getInteger(R.integer.detail_font_size_extra_large).toFloat()//
        )
    }
}

fun View.adjustFontSize(pref: PreferenceHelper, vararg textView: TextView) {
    textView[0].setupAdjustFontSize(
        pref,
        resources.getInteger(R.integer.title_font_size_small).toFloat(),
        resources.getInteger(R.integer.title_font_size_normal).toFloat(),
        resources.getInteger(R.integer.title_font_size_large).toFloat(),
        resources.getInteger(R.integer.title_font_size_extra_large).toFloat()
    )
    textView[1].setupAdjustFontSize(
        pref,
        resources.getInteger(R.integer.subtitle_font_size_small).toFloat(),
        resources.getInteger(R.integer.subtitle_font_size_normal).toFloat(),
        resources.getInteger(R.integer.subtitle_font_size_large).toFloat(),
        resources.getInteger(R.integer.subtitle_font_size_extra_large).toFloat()
    )
}

fun EditText.setupFilter(
    before: ((CharSequence?, Int, Int, Int) -> Unit)?,
    change: ((CharSequence?, Int, Int, Int) -> Unit)?,
    after: ((Editable?) -> Unit)?
) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            before?.let { before(p0, p1, p2, p3) }
        }

        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            change?.let { change(p0, p1, p2, p3) }
        }

        override fun afterTextChanged(p0: Editable?) {
            after?.let { after(p0) }
        }
    })
}

fun correctSound(context: Context) {
    MediaPlayer.create(context, R.raw.correct_answer).also {
        it.start()
    }
}

@SuppressLint("ServiceCast")
fun vibratePhone(context: Context) {
    val vibrator =
    if (Build.VERSION.SDK_INT >= 23) {
         context.getSystemService(Vibrator::class.java)
    } else {
        context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }
    if (Build.VERSION.SDK_INT >= 26) {
        vibrator.vibrate(
            VibrationEffect.createOneShot(
                TIME_VIBRATE,
                VibrationEffect.DEFAULT_AMPLITUDE
            )
        )
    } else {
        vibrator.vibrate(TIME_VIBRATE)
    }
}

fun <T> Fragment.handleMutableLiveData(
    data: MutableLiveData<Resource<T>>,
    progressBar: ProgressBar?,
    success: (T) -> Unit
) {
    data.observe(viewLifecycleOwner) { response ->
        when (response) {
            is Resource.Loading -> progressBar?.let { showProgressBar(true, it) }
            is Resource.Success -> {
                progressBar?.let { showProgressBar(false, it) }
                response.data?.let { success(it) }
            }
            is Resource.Error -> response.message?.let { showToast(it) }
        }
    }
}

fun <B : ViewDataBinding?> BaseFragment<B>.setupSameRecyclerView(
    viewModel: DictionaryViewModel,
    recyclerView: RecyclerView,
    adapter: DictionaryAdapter,
    onScrolled: (RecyclerView, Int, Int) -> Unit
) {
    recyclerView.setupAdapter(requireContext(), adapter)
    recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
            super.onScrolled(recyclerView, dx, dy)
            onScrolled(recyclerView, dx, dy)
        }
    })
    adapter.setOnItemClickListener { type, item, position ->
        when (type) {
            R.id.btnSpeak -> {
                showToast(item.word)
                speakWord(
                    requireContext(),
                    item.word,
                    prefHelper.readSpeedSpeak(PREF_SPEED_SPEAK, 1.0f)
                )
            }
            R.id.btnFavorite -> {
                viewModel.modifyFavoriteWord(item)
                showToast(
                    if (!item.isFavorite) {
                        getString(
                            R.string.success_add_favorite_word,
                            item.word
                        )
                    } else {
                        getString(
                            R.string.success_remove_favorite_word,
                            item.word
                        )
                    }
                )
                adapter._data[position].isFavorite = !item.isFavorite
                adapter.notifyItemChanged(position)
            }
            R.id.btnShare -> {
                requestPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ),
                )
                requestListener = {
                    // permission granted
                    DialogView(activity as MainActivity).also {
                        it.showShareDialog(item)
                    }
                }
            }
            else -> {
                navigate(
                    R.id.action_dictionaryFragment_to_detailFragment,
                    Constants.BUNDLE_WORD,
                    item
                )
            }
        }
    }
}

fun Fragment.onBackPress() {
    displayDialog(
        requireContext(),
        getString(R.string.dialog_attention),
        getString(R.string.dialog_quit_game),
        getString(R.string.dialog_accept),
        getString(R.string.dialog_cancel),
        { _, _ ->
            (activity as PlayActivity).finish()
        },
        null
    )
}

fun convertFavToWord(item: Favorite): Word =
    Word(item.favId, item.av, item.dnpn, item.aa, item.mean)

fun convertWordToFav(item: Word): Favorite =
    Favorite(item.word, item.av, item.dnpn, item.aa, item.mean)

fun getCorrectAnswer(correct: String): String {
    return if (correct.contains(";")) {
        val c = correct.substring(0, correct.indexOf(";"))
        c
    } else correct
}

fun <B : ViewDataBinding?> BaseFragment<B>.requestPermission(request: () -> Unit) {
    requestPermissionLauncher.launch(
        arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        ),
    )
    requestListener = {
        // permission granted
        request()
    }
}




