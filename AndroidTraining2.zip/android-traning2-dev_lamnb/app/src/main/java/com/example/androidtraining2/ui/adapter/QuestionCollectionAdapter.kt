package com.example.androidtraining2.ui.adapter


import com.example.androidtraining2.R
import com.example.androidtraining2.data.local.entity.QuestionCollection
import com.example.androidtraining2.databinding.ItemQuestionCollectionBinding
import com.example.androidtraining2.presentation.base.BaseAdapter

class QuestionCollectionAdapter(
    quesCoList: MutableList<QuestionCollection>
) : BaseAdapter<ItemQuestionCollectionBinding, QuestionCollection>(quesCoList) {
    override val layoutId: Int
        get() = R.layout.item_question_collection

    override fun bind(
        binding: ItemQuestionCollectionBinding,
        item: QuestionCollection,
        position: Int
    ) {
        binding.apply {
            tvName.text = item.quesColName
            ivQuesCol.setImageResource(item.image)
            root.setOnClickListener {
                onItemClick?.let { it(123, item, position) }
            }
        }
    }
}