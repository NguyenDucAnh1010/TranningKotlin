package com.example.androidtraining2.ui.fragment.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.databinding.ViewDataBinding
import com.example.androidtraining2.R
import com.example.androidtraining2.databinding.FragmentSettingsBinding
import com.example.androidtraining2.extension.*
import com.example.androidtraining2.presentation.base.BaseFragment
import com.example.androidtraining2.ui.MainActivity
import com.example.androidtraining2.utils.Constants.PREF_FONT_SIZE
import com.example.androidtraining2.utils.Constants.PREF_SPEED_SPEAK
import com.example.androidtraining2.utils.Constants.SHARE_APPLICATION
import com.example.androidtraining2.utils.Constants.VALUE_FONT_SIZE_EXTRA_LARGE
import com.example.androidtraining2.utils.Constants.VALUE_FONT_SIZE_LARGE
import com.example.androidtraining2.utils.Constants.VALUE_FONT_SIZE_NORMAL
import com.example.androidtraining2.utils.Constants.VALUE_FONT_SIZE_SMALL
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class SettingsFragment : BaseFragment<FragmentSettingsBinding>() {

    override val bindingInflater: (LayoutInflater) -> ViewDataBinding
        get() = FragmentSettingsBinding::inflate

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupSettings()
        binding.btnShare.setOnClickListener {
            requestPermission {
                shareApplication(activity as MainActivity, "logo_app", SHARE_APPLICATION)
            }
        }
    }

    private fun setupSettings() {
        binding.apply {
            tvSpeed.text = getString(
                R.string.settings_speed,
                formatFloat(prefHelper.readSpeedSpeak(PREF_SPEED_SPEAK, 1.0f))
            )
            seekBar.setupAdjustSpeed(prefHelper, { _, p1, _ ->
                val speed = formatFloat(p1 / 50f)
                tvSpeed.text = getString(
                    R.string.settings_speed,
                    speed
                )
                prefHelper.saveSpeedSpeak(PREF_SPEED_SPEAK, speed.toFloat())
            }, null,
                { seekBar ->
                    // jump seekbar to fixed position: (change 5 for jumping)
                    seekBar?.let {
                        it.progress = ((it.progress + (5 / 2)) / 5) * 5
                    }
                })
            btnTestSound.setOnClickListener {
                showToast("Hello World")
                speakWord(
                    requireContext(),
                    "Hello World",
                    prefHelper.readSpeedSpeak(PREF_SPEED_SPEAK, 1.0f)
                )
            }
            tvTestFontSize.setupAdjustFontSize(prefHelper, null, null, null, null)
            when (prefHelper.readFontSize(PREF_FONT_SIZE, VALUE_FONT_SIZE_NORMAL)) {
                VALUE_FONT_SIZE_SMALL -> rbSmall.isChecked = true
                VALUE_FONT_SIZE_NORMAL -> rbNormal.isChecked = true
                VALUE_FONT_SIZE_LARGE -> rbLarge.isChecked = true
                VALUE_FONT_SIZE_EXTRA_LARGE -> rbExtraLarge.isChecked = true
            }
            radioGroup.setOnCheckedChangeListener { _, i ->
                when (i) {
                    R.id.rbSmall -> prefHelper.saveFontSize(PREF_FONT_SIZE, VALUE_FONT_SIZE_SMALL)
                    R.id.rbNormal -> prefHelper.saveFontSize(PREF_FONT_SIZE, VALUE_FONT_SIZE_NORMAL)
                    R.id.rbLarge -> prefHelper.saveFontSize(PREF_FONT_SIZE, VALUE_FONT_SIZE_LARGE)
                    R.id.rbExtraLarge -> prefHelper.saveFontSize(
                        PREF_FONT_SIZE,
                        VALUE_FONT_SIZE_EXTRA_LARGE
                    )
                }
                tvTestFontSize.setupAdjustFontSize(prefHelper, null, null, null, null)
            }
        }
    }


}