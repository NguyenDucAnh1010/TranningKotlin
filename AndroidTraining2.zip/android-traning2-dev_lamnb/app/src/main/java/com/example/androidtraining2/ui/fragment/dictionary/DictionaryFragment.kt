package com.example.androidtraining2.ui.fragment.dictionary

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.activityViewModels
import com.example.androidtraining2.data.local.entity.Word
import com.example.androidtraining2.databinding.FragmentDictionaryBinding
import com.example.androidtraining2.extension.handleMutableLiveData
import com.example.androidtraining2.extension.setupFilter
import com.example.androidtraining2.extension.setupSameRecyclerView
import com.example.androidtraining2.presentation.base.BaseFragment
import com.example.androidtraining2.ui.adapter.DictionaryAdapter
import com.example.androidtraining2.ui.viewmodels.DictionaryViewModel
import com.example.androidtraining2.utils.Constants.DISPLAY_LIST
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class DictionaryFragment : BaseFragment<FragmentDictionaryBinding>() {

    private val viewModel by activityViewModels<DictionaryViewModel>()
    private lateinit var adapter: DictionaryAdapter
    private lateinit var filterAdapter: DictionaryAdapter

    override val bindingInflater: (LayoutInflater) -> ViewDataBinding
        get() = FragmentDictionaryBinding::inflate

    @SuppressLint("NotifyDataSetChanged")
    override fun onViewCreated(view: View, savedState: Bundle?) {
        super.onViewCreated(view, savedState)
        adapter = DictionaryAdapter(mutableListOf(), prefHelper)
        filterAdapter = DictionaryAdapter(mutableListOf(), prefHelper)
        binding.etSearch.setupFilter(
            null, { editable, _, _, _ ->
                editable?.let {
                    if (editable.isNotEmpty()) {
                        getFilter("${editable}%")
                    } else {
                        getWords()
                    }
                }
            }, null
        )
        getWords()
    }

    private fun getWords() {
        if (viewModel.state != null && viewModel.index != 0) {
            viewModel.getWords(viewModel.index * 2)
            handleMutableLiveData(viewModel.words, binding.progressBarCenter) {
                adapter.setData(it as MutableList<Word>)
                binding.rvWords.layoutManager?.onRestoreInstanceState(viewModel.restoreRecyclerViewState())
                viewModel.state = null
            }
        } else {
            viewModel.index = 0
            viewModel.getWords(viewModel.length)
            handleMutableLiveData(viewModel.words, binding.progressBarCenter) {
                adapter.setData(it as MutableList<Word>)
            }
        }
        setupWordsRecyclerView()
    }

    private fun getFilter(word: String) {
        viewModel.filterIndex = 0
        viewModel.filterWord(viewModel.filterIndex, word)
        handleMutableLiveData(viewModel.filters, binding.progressBar) {
            if (viewModel.filterIndex == 0)
                filterAdapter.setData(it as MutableList<Word>)
            else
                filterAdapter.appendData(it as MutableList<Word>)
        }
        setupFiltersRecyclerView(word)
    }

    private fun setupWordsRecyclerView() {
        binding.rvWords.visibility = View.VISIBLE
        binding.rvFilters.visibility = View.GONE
        setupSameRecyclerView(viewModel, binding.rvWords, adapter) { recyclerView, _, _ ->
            if (!recyclerView.canScrollVertically(1)) { //1 for down
                viewModel.index += DISPLAY_LIST
                viewModel.getLoadMoreWords(viewModel.index)
                recyclerView.post {
                    handleMutableLiveData(viewModel.loadMoreWords, binding.progressBar) {
                        adapter.appendData(it as MutableList<Word>)
                    }
                }
            }
        }
    }

    private fun setupFiltersRecyclerView(word: String) {
        binding.rvWords.visibility = View.GONE
        binding.rvFilters.visibility = View.VISIBLE
        setupSameRecyclerView(viewModel, binding.rvFilters, filterAdapter) { recyclerView, _, _ ->
            if (!recyclerView.canScrollVertically(1)) { //1 for down
                viewModel.filterIndex += DISPLAY_LIST
                viewModel.filterWord(viewModel.filterIndex, word)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding.rvWords.layoutManager?.onSaveInstanceState()?.let {
            viewModel.saveRecyclerViewState(it)
        }
    }
}