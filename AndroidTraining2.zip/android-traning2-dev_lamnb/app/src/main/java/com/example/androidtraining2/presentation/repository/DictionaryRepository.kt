package com.example.androidtraining2.presentation.repository

import androidx.lifecycle.LiveData
import com.example.androidtraining2.data.local.entity.*
import com.example.androidtraining2.data.local.entity.relations.QuesColWithTopics
import com.example.androidtraining2.data.local.entity.relations.QuesColsAndTopics
import com.example.androidtraining2.data.local.entity.relations.TopicWithQuestions

interface DictionaryRepository {

    suspend fun getAllWord(index: Int): List<Word>

    suspend fun getWords(length: Int): List<Word>

    suspend fun filterWord(index: Int, word: String): List<Word>

    // favorite

    suspend fun addFavorite(favorite: Favorite)

    suspend fun removeFavorite(favorite: Favorite)

    suspend fun getFavoriteWords(): List<Favorite>

    suspend fun getFavoriteWord(word: String): Favorite?

    // game
    suspend fun addQuesColl(quesCollection: QuestionCollection)

    fun getQuestionCollections(): LiveData<List<QuestionCollection>>

    suspend fun addTopic(vararg topic: Topic)

    fun getTopics(): LiveData<List<Topic>>

    suspend fun addQuestion(vararg question: Question)

    fun getQuestions(topicName: String, type: String): LiveData<List<Question>>

    suspend fun getTopicsOfQuesCol(quesColName:String):QuesColWithTopics

    fun getQuestionsOfTopic(topicName: String): LiveData<TopicWithQuestions>

    // Score
    suspend fun addScore(score: Score)

    fun getAllScore():LiveData<List<Score>>
}