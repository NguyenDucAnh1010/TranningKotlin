package com.example.androidtraining2.ui.fragment.detail

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import androidx.annotation.RequiresApi
import androidx.databinding.ViewDataBinding
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.androidtraining2.R
import com.example.androidtraining2.databinding.FragmentDetailBinding
import com.example.androidtraining2.extension.setupActionBar
import com.example.androidtraining2.extension.setupAdjustFontSize
import com.example.androidtraining2.extension.speakWord
import com.example.androidtraining2.presentation.base.BaseFragment
import com.example.androidtraining2.ui.MainActivity
import com.example.androidtraining2.utils.Constants.PREF_SPEED_SPEAK
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class DetailFragment : BaseFragment<FragmentDetailBinding>() {

    private val args by navArgs<DetailFragmentArgs>()

    override val bindingInflater: (LayoutInflater) -> ViewDataBinding
        get() = FragmentDetailBinding::inflate

    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupMenu = { menu, inflater ->
            inflater.inflate(R.menu.toolbar_detail_word, menu)
        }
        adjustFontSize()
        (activity as MainActivity).setupActionBar(
            binding.layoutAppBar.toolbar,
            args.word.word,
            true
        )
        binding.tvAv.text = Html.fromHtml(
            args.word.av?.let { String(it, Charsets.UTF_8) },
            Html.FROM_HTML_MODE_COMPACT
        )
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> findNavController().navigateUp()
            R.id.acSpeak -> speakWord(
                requireContext(),
                args.word.word,
                prefHelper.readSpeedSpeak(PREF_SPEED_SPEAK, 1.0f)
            )
        }
        return true
    }

    private fun adjustFontSize() {
        binding.tvAv.setupAdjustFontSize(prefHelper, null, null, null, null)
    }

}