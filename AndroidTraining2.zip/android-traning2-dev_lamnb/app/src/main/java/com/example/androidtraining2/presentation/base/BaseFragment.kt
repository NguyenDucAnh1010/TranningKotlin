package com.example.androidtraining2.presentation.base

import android.os.Bundle
import android.view.*
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.observe
import androidx.navigation.fragment.findNavController
import com.example.androidtraining2.R
import com.example.androidtraining2.extension.displayDialog
import com.example.androidtraining2.extension.requirePermission
import com.example.androidtraining2.extension.showProgressBar
import com.example.androidtraining2.extension.showToast
import com.example.androidtraining2.presentation.preference.PreferenceHelper
import com.example.androidtraining2.utils.Resource
import javax.inject.Inject

abstract class BaseFragment<B : ViewDataBinding?> : Fragment() {

    @Inject
    lateinit var prefHelper: PreferenceHelper

    private var _binding: ViewDataBinding? = null

    @Suppress("UNCHECKED_CAST")
    protected val binding: B
        get() = _binding as B

    @Suppress("UNCHECKED_CAST")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = bindingInflater(inflater) as B
        setHasOptionsMenu(true)
        return _binding!!.root
    }

    var handleBackPress:(()->Unit)? = null

    protected abstract val bindingInflater: (LayoutInflater) -> ViewDataBinding

    protected var setupMenu: ((Menu, MenuInflater) -> Unit)? = null
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        setupMenu?.let { it(menu, inflater) }
        super.onCreateOptionsMenu(menu, inflater)
    }

    var requestListener: (() -> Unit)? = null
    val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            permissions.forEach { (s, _) ->
                if (permissions[s] == false) {
                    if (!shouldShowRequestPermissionRationale(s)) {
                        displayDialog(requireContext(),
                            title = getString(R.string.dialog_attention),
                            message = getString(
                                R.string.dialog_require_permission
                            ),
                            accept = getString(R.string.dialog_accept),
                            cancel = getString(R.string.dialog_cancel),
                            positiveListener = { _, _ ->
                                requirePermission(requireContext())
                            },
                            negativeListener = { _, _ ->
                                showToast(getString(R.string.error_permission_denied))
                            }
                        )
                    } else
                        showToast(getString(R.string.error_permission_denied))
                    return@registerForActivityResult
                }
            }
            requestListener?.let { it() }
        }

}