package com.example.androidtraining2.ui.fragment.favorite

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.activityViewModels
import com.example.androidtraining2.R
import com.example.androidtraining2.data.local.entity.Favorite
import com.example.androidtraining2.databinding.FragmentFavoriteBinding
import com.example.androidtraining2.extension.*
import com.example.androidtraining2.presentation.base.BaseFragment
import com.example.androidtraining2.ui.MainActivity
import com.example.androidtraining2.ui.adapter.FavoriteAdapter
import com.example.androidtraining2.ui.dialog.DialogView
import com.example.androidtraining2.ui.viewmodels.DictionaryViewModel
import com.example.androidtraining2.utils.Constants.BUNDLE_WORD
import com.example.androidtraining2.utils.Constants.PREF_SPEED_SPEAK
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class FavoriteFragment : BaseFragment<FragmentFavoriteBinding>() {

    private val viewModel by activityViewModels<DictionaryViewModel>()
    private lateinit var adapter: FavoriteAdapter

    override val bindingInflater: (LayoutInflater) -> ViewDataBinding
        get() = FragmentFavoriteBinding::inflate

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.getFavoriteWords()
        handleMutableLiveData(viewModel.favoriteWords, null) {
            adapter.setData(it as MutableList<Favorite>)
        }
        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        adapter = FavoriteAdapter(mutableListOf(), prefHelper)
        binding.rvFavorites.setupAdapter(requireContext(), adapter)
        adapter.apply {
            setOnItemClickListener { type, item, position ->
                when (type) {
                    R.id.btnSpeak -> {
                        showToast(item.favId)
                        speakWord(
                            requireContext(),
                            item.favId,
                            prefHelper.readSpeedSpeak(PREF_SPEED_SPEAK, 1.0f)
                        )
                    }
                    R.id.btnFavorite -> {
                        displayDialog(
                            requireContext(),
                            title = getString(R.string.dialog_attention),
                            message = getString(R.string.dialog_remove_word_from_favorites),
                            accept = getString(R.string.dialog_accept),
                            cancel = getString(R.string.dialog_cancel),
                            positiveListener = { _, _ ->
                                viewModel.removeFavorite(item)
                                showToast(
                                    getString(
                                        R.string.success_remove_favorite_word,
                                        item.favId
                                    )
                                )
                                _data.remove(item)
                                notifyItemRemoved(position)
                                notifyItemRangeChanged(position, _data.size)
                            },
                            null
                        )
                    }
                    R.id.btnShare -> {
                        requestPermission {
                            // permission granted
                            DialogView(activity as MainActivity).also {
                                it.showShareDialog(convertFavToWord(item))
                            }
                        }
                    }
                    else -> {
                        navigate(
                            R.id.action_favoriteFragment_to_detailFragment,
                            BUNDLE_WORD,
                            convertFavToWord(item)
                        )
                    }
                }
            }
        }
    }

}